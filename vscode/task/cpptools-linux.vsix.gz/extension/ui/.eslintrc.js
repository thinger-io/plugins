module.exports = {
    "parserOptions": {
        "project": "test.tsconfig.json",
        "sourceType": "module"
    }
};
